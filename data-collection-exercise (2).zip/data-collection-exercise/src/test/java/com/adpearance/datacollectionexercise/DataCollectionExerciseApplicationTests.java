package com.adpearance.datacollectionexercise;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DataCollectionExerciseApplicationTests {

	@Test
	void contextLoads() {
	}

}

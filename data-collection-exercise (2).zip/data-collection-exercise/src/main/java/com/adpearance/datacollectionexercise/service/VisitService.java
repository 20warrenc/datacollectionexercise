package com.adpearance.datacollectionexercise.service;

import javax.persistence.EntityManager;
import javax.transaction.Transactional;

import com.adpearance.datacollectionexercise.model.Visit;

import org.springframework.stereotype.Service;

@Service
@Transactional
public class VisitService {
    EntityManager entityManager;

    public VisitService(EntityManager entityManager) {
        this.entityManager = entityManager;
    }

    public Long saveVisit(Visit visit) {
        entityManager.persist(visit);
        return visit.getId();
    }
}

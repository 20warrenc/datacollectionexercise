package com.adpearance.datacollectionexercise.service;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.util.Date;

import javax.servlet.http.Cookie;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

import com.adpearance.datacollectionexercise.model.Visitor;
import com.adpearance.datacollectionexercise.model.Visit;

@Controller
public class WebController {

	@Autowired
	private VisitorService visitorService;
	@Autowired
	private VisitService visitService;

	@GetMapping("/")
    public String main(HttpServletRequest request, HttpServletResponse response) {

		// Check for cookie (name of cookie is up to you)
		Cookie[] cookies = request.getCookies();
		if(cookies != null) {
			for(Cookie cookie : cookies) {
				if(cookie.getName().equals("dceid")) {
					Visit visit = new Visit();
					Date date = new Date();
					visit.setDate(date);
					Long visitor_id = Long.parseLong((cookie.getValue()));
					visit.setVisitorId(visitor_id);
					visitService.saveVisit(visit);
				}
			}
		}
		else {
			// Create Visitor
			Visitor visitor = new Visitor();
			Long id = visitorService.saveVisitor(visitor);
			String cookieId = String.format("%d", id);
			// Log Visit
			Visit visit = new Visit();
			Date date = new Date();
			visit.setDate(date);
			visit.setVisitor(visitor);
			//Create and send cookie
			Cookie newcookie = new Cookie("dceid", cookieId);
			response.addCookie(newcookie);
		}
		return "index";
	}
}

package com.adpearance.datacollectionexercise.repository;

import com.adpearance.datacollectionexercise.model.Form;
import org.springframework.data.jpa.repository.JpaRepository;

public interface FormRepository extends JpaRepository<Form, Long>{
    
}

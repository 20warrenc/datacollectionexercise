package com.adpearance.datacollectionexercise.service;

import com.adpearance.datacollectionexercise.model.Form;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.beans.factory.annotation.Autowired;

@RestController
@RequestMapping("visitor")
public class VisitorController {

	// TODO inject VisitorService

	@Autowired
	private VisitorService visitorService;
	
	@PostMapping(value="/add-form")
    public ResponseEntity<?> execute(@RequestParam(name = "first_name", required = false) String first_name,
									 @RequestParam(name = "last_name", required = false) String last_name,
									 @RequestParam(name = "email_address", required = true) String email_address,	//At least give us a way to contact you
									 @RequestParam(name = "phone_number", required = false) String phone_number,
									 @CookieValue(value = "dceid") Long visitor_id) throws Exception {

		// TODO call VisitorService
		Form form = new Form();
		if(first_name != null) {
			form.setFirstName(first_name);
		}
		if(last_name != null) {
			form.setLastName(last_name);
		}
		if(phone_number != null) {
			form.setPhoneNumber(phone_number);
		}
		if(email_address != null) {
			form.setEmailAddress(email_address);
		}
		visitorService.addForm(visitor_id, form);
		

		// TODO update to account for success and failure status
		return new ResponseEntity<>(HttpStatus.OK);
	}
}

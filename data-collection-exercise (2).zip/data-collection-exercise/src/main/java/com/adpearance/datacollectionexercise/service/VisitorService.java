package com.adpearance.datacollectionexercise.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.persistence.EntityManager;
import javax.transaction.Transactional;

import com.adpearance.datacollectionexercise.model.Form;
import com.adpearance.datacollectionexercise.model.Visitor;
import com.adpearance.datacollectionexercise.repository.FormRepository;
import com.adpearance.datacollectionexercise.repository.VisitorRepository;


import java.util.List;

@Service
@Transactional
public class VisitorService {
	EntityManager entityManager;

	@Autowired
	private VisitorRepository visitorRepository;
	@Autowired
	private FormRepository formRepository;

	public VisitorService(EntityManager entityManager) {
		this.entityManager = entityManager;
	}

	public List<Visitor> listAllVisitor() {
		return visitorRepository.findAll();
	}

	public Long saveVisitor(Visitor visitor) {
		entityManager.persist(visitor);
		return visitor.getId();
	}

	public Visitor getVisitor(Long id) {
		return visitorRepository.findById(id).get();
	}

	@Transactional
	public void addForm(Long visitorId, Form form) throws Exception {
		form.setVisitor(getVisitor(visitorId));
		form.setVisitorId(visitorId);
		formRepository.save(form);
	}

}
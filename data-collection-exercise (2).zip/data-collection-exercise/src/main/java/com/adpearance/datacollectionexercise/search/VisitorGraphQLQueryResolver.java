package com.adpearance.datacollectionexercise.search;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.adpearance.datacollectionexercise.model.Visitor;
import com.coxautodev.graphql.tools.GraphQLQueryResolver;

@Component
public class VisitorGraphQLQueryResolver implements GraphQLQueryResolver {
	public List<Visitor> searchVisitors() throws Exception {
		
		// TODO Use JPA to query Visitor
		
		// Replace with actual list of Visitors
		return new ArrayList<Visitor>();
	}
}

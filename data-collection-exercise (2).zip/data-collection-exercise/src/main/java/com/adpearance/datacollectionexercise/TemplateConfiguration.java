package com.adpearance.datacollectionexercise;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.thymeleaf.spring5.SpringTemplateEngine;
import org.thymeleaf.templateresolver.FileTemplateResolver;

@Configuration
public class TemplateConfiguration {
	
	@Autowired
    private SpringTemplateEngine templateEngine;

	
	@PostConstruct
    public void extension() {
		FileTemplateResolver resolver = new FileTemplateResolver();
        resolver.setPrefix("./templates/");
        resolver.setSuffix(".html");
        resolver.setOrder(templateEngine.getTemplateResolvers().size());
        resolver.setCacheable(false);
        resolver.setTemplateMode("LEGACYHTML5");
        templateEngine.addTemplateResolver(resolver);
	}
}
package com.adpearance.datacollectionexercise.repository;

import com.adpearance.datacollectionexercise.model.Visitor;
import org.springframework.data.jpa.repository.JpaRepository;

public interface VisitorRepository extends JpaRepository<Visitor, Long>{
    
}
